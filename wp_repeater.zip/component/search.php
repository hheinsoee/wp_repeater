<nav>
    <a href="<?=rootDir();?>" title="home"><img src="<?=rootDir();?>/logo.svg" alt="" class="logo"></a>
    <form action="<?=rootDir();?>" class="search">
        <input class="form-control" type="text" placeholder="Search.." name="search">
        <button type="submit">Search</button>
    </form>
</nav>