<?php
echo 'hello';
echo @$_GET['_fields'];
?>